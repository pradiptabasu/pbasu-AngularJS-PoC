// import store from '../store';
//
//
//
//
// export default connect(mapStateToProps, mapDispatchToProps) {
//     return function (Component) {
//         return Component(store, props);
//     }
// }
const defaultState = {
};

// XXX maybe this file need to be removed

export default function (state = defaultState, action: any) {
    return state
}